-- Softaculous SQL Dump
-- http://www.softaculous.com
--
-- Host: localhost
-- Generation Time: January 20, 2016, 5:55 pm
-- Server version: 5.6.28
-- PHP Version: 5.4.31

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `consultl_wp399`
--

-- --------------------------------------------------------

--
-- Table structure for table`wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table 'wp_comments'
--

INSERT INTO `wp_comments` VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-03-18 17:55:27', '2015-03-18 17:55:27', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0),
(2, 1, 'Catherine', 'xlshtc@dayrep.com', 'http://s.ihaus.co.uk/x3', '104.168.50.76', '2015-04-10 05:06:04', '2015-04-10 05:06:04', 'Hi, my name is Catherine and I am the marketing manager at StarSEO Marketing. I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your site on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://tf3.info/nf - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the network I am talking about. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular blogs are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://tf3.info/nf', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(3, 1, 'Catherine', 'cpqlcjbaaj@dayrep.com', 'http://tf3.info/nf', '104.168.46.51', '2015-04-11 03:55:02', '2015-04-11 03:55:02', 'Hi, my name is Catherine and I am the marketing manager at StarSEO Marketing. I was just looking at your Hello world! | Consult Lawyers site and see that your website has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and most of the users are interested in niches like yours. By getting your site on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can find out more about it here: http://1be.info/3o3a - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your website on the network I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything. All the popular websites are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Find out more here: http://cabkit.in/9mt5', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(4, 1, 'Catherine', 'zsasafsb@mail.com', 'http://1be.info/3o3a', '104.168.50.13', '2015-04-16 11:20:11', '2015-04-16 11:20:11', 'Hi, my name is Catherine and I am the sales manager at StarSEO Marketing. I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and most of the users are interested in niches like yours. By getting your website on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://s.ihaus.co.uk/x3 - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the network I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular sites are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Find out more here: http://s.ihaus.co.uk/x3  - or to unsubscribe please go here: http://tf3.info/sb', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(5, 1, 'Janette', 'lmbnjplz@mail.com', 'http://dl4.pl/im7p', '198.23.215.56', '2015-04-18 22:46:22', '2015-04-18 22:46:22', 'Hi my name is Janette and I just wanted to drop you a quick note here instead of calling you. I came to your Hello world! | Consult Lawyers page and noticed you could have a lot more traffic. I have found that the key to running a successful website is making sure the visitors you are getting are interested in your niche. There is a company that you can get targeted visitors from and they let you try their service for free for 7 days. I managed to get over 300 targeted visitors to day to my website. Check it out here: http://pixz.nu/2fqB', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)', '', 0, 0),
(6, 1, 'Olivie', 'njvrhyawuwr@hotmail.com', 'http://9n3.us/7uza', '104.168.63.93', '2015-04-20 07:25:57', '2015-04-20 07:25:57', 'Hi my name is Olivie and I just wanted to drop you a quick note here instead of calling you. I came to your Hello world! | Consult Lawyers page and noticed you could have a lot more hits. I have found that the key to running a popular website is making sure the visitors you are getting are interested in your subject matter. There is a company that you can get targeted visitors from and they let you try the service for free for 7 days. I managed to get over 300 targeted visitors to day to my site. Visit them here: http://bbqr.me/mu', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)', '', 0, 0),
(7, 1, 'Victoire', 'ufmvqkpcfez@ymail.com', 'http://ft1.info/8ogz', '23.94.186.73', '2015-04-23 01:14:30', '2015-04-23 01:14:30', 'Hi, my name is Victoire and I am the marketing manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your website on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://todochiapas.mx/C/369 - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the service I am talking about. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything at all. All the popular websites are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://ft1.info/8ogz  - or to unsubscribe please go here: http://bbqr.me/n1', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(8, 1, 'Victoire', 'njkprevwrn@ymail.com', 'http://stg2bio.co/10fv', '23.94.181.74', '2015-04-23 21:32:56', '2015-04-23 21:32:56', 'Hi, my name is Victoire and I am the marketing manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website network which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your site on this network you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can find out more about it here: http://tgi.link/4wzj - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your site on the service I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular websites are using this service to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://ft1.info/8ogz  - or to unsubscribe please go here: http://bbqr.me/n1', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(9, 1, 'Olivie', 'akzwxxwmtwm@hotmail.com', 'http://esyok.com/shirt/b9', '198.23.212.180', '2015-04-24 21:39:51', '2015-04-24 21:39:51', 'Hi my name is Olivie and I just wanted to drop you a quick note here instead of calling you. I came to your Hello world! | Consult Lawyers page and noticed you could have a lot more hits. I have found that the key to running a successful website is making sure the visitors you are getting are interested in your subject matter. There is a company that you can get targeted traffic from and they let you try the service for free for 7 days. I managed to get over 300 targeted visitors to day to my website. Visit them here: http://garye.co/6y', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)', '', 0, 0),
(10, 1, 'Olivie', 'ybzhhr@hotmail.com', 'http://garye.co/6y', '104.168.63.93', '2015-04-25 19:26:54', '2015-04-25 19:26:54', 'Hi my name is Olivie and I just wanted to drop you a quick note here instead of calling you. I discovered your Hello world! | Consult Lawyers page and noticed you could have a lot more hits. I have found that the key to running a popular website is making sure the visitors you are getting are interested in your niche. There is a company that you can get targeted traffic from and they let you try their service for free for 7 days. I managed to get over 300 targeted visitors to day to my site. Visit them here: http://garye.co/6y', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(11, 1, 'Brigitte', 'teejqses@ymail.com', 'http://stg2bio.co/10fz', '104.168.46.51', '2015-04-26 14:15:05', '2015-04-26 14:15:05', 'Hi, my name is Brigitte and I am the sales manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for topics like yours. By getting your website on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://innovad.ws/ore1q - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your site on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything. All the popular websites are using this network to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Read more here: http://stg2bio.co/10fz  - or to unsubscribe please go here: http://todochiapas.mx/C/36p', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(12, 1, 'Brigitte', 'pumixwa@ymail.com', 'http://stg2bio.co/10fz', '104.168.46.51', '2015-04-29 23:44:58', '2015-04-29 23:44:58', 'Hi, my name is Brigitte and I am the sales manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers site and see that your website has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your site on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://anders.ga/w-6x2 - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the service I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular websites are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Read more here: http://anders.ga/w-6x2  - or to unsubscribe please go here: http://todochiapas.mx/C/36p', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(13, 1, 'Olivie', 'mmuhvtxkbd@hotmail.com', 'http://esyok.com/shirt/b9', '198.23.212.180', '2015-04-30 05:23:58', '2015-04-30 05:23:58', 'Hi my name is Olivie and I just wanted to drop you a quick note here instead of calling you. I came to your Hello world! | Consult Lawyers page and noticed you could have a lot more hits. I have found that the key to running a popular website is making sure the visitors you are getting are interested in your subject matter. There is a company that you can get targeted traffic from and they let you try the service for free for 7 days. I managed to get over 300 targeted visitors to day to my site. Check it out here: http://tf3.info/uu', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(14, 1, 'Brigitte', 'fktreadvg@ymail.com', 'http://anders.ga/w-6x2', '23.94.186.73', '2015-05-08 02:17:47', '2015-05-08 02:17:47', 'Hi, my name is Brigitte and I am the marketing manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website network which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your website on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can find out more about it here: http://claimyourexcellence.info/24o - Now, let me ask you... Do you need your website to be successful to maintain your way of life? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your website on the service I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything at all. All the popular blogs are using this service to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://innovad.ws/ore1q  - or to unsubscribe please go here: http://todochiapas.mx/C/36p', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(15, 1, 'Olivie', 'tnegikzkwq@hotmail.com', 'http://9n3.us/7uza', '104.168.63.23', '2015-05-08 20:11:50', '2015-05-08 20:11:50', 'Hi my name is Olivie and I just wanted to drop you a quick note here instead of calling you. I came to your Hello world! | Consult Lawyers page and noticed you could have a lot more traffic. I have found that the key to running a popular website is making sure the visitors you are getting are interested in your subject matter. There is a company that you can get targeted traffic from and they let you try the service for free for 7 days. I managed to get over 300 targeted visitors to day to my website. Check it out here: http://esyok.com/shirt/b9', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(16, 1, 'Delphine', 'awywqso@yahoo.co.uk', 'http://s.marcusmo.co.uk/5ot', '23.94.176.10', '2015-05-15 21:23:00', '2015-05-15 21:23:00', 'Hi, my name is Delphine and I am the marketing manager at SwingSEO Solutions. I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website network which already has more than 16 million users, and the majority of the users are looking for niches like yours. By getting your site on this network you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://zoy.bz/4nm - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular sites are using this network to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Read more here: http://zoy.bz/4nm - or to unsubscribe please go here: http://innovad.ws/8h9dp', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', 0, 0),
(17, 1, 'interstate removals', 'raqudatd@gmail.com', 'http://www.phtele.com.br/?option=com_k2&amp;view=itemlist&amp;task=user&amp;id=137316', '69.107.105.19', '2015-06-17 06:58:28', '2015-06-17 06:58:28', 'What''s up, I check your new stuff regularly. Your humoristic style is awesome, keep up the good work!|', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', 0, 0),
(18, 1, 'Laetitia', 'pcssyp@dayrep.com', 'http://cabkit.in/e137', '23.94.173.64', '2015-07-11 09:20:23', '2015-07-11 09:20:23', 'Hi, my name is Laetitia and I am the marketing manager at CorpSEO marketing. I was just looking at your Hello world! | Consult Lawyers site and see that your website has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website network which already has more than 16 million users, and most of the users are looking for niches like yours. By getting your site on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://bbqr.me/4fj5 - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your website on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular blogs are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://gf10.com.br/url/iq2f', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(19, 1, 'Donna', 'ryulwtj@tom.com', 'http://claimyourexcellence.info/12ny', '172.245.120.66', '2015-07-27 13:34:01', '2015-07-27 13:34:01', 'I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website network which already has more than 16 million users, and the majority of the users are looking for topics like yours. By getting your website on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://www.urlator.co/w7uk - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your site on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular websites are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://gf10.com.br/url/iq2f', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', 0, 0),
(20, 1, 'Donna', 'cbfbly@tom.com', 'http://bbqr.me/4fj5', '107.173.157.59', '2015-08-03 15:18:54', '2015-08-03 15:18:54', 'I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and the majority of the users are interested in websites like yours. By getting your site on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://bbqr.me/4fj5 - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your site on the network I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything. All the popular blogs are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://bbqr.me/4fj5', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)', '', 0, 0),
(21, 1, 'Valerie', 'qirvjrzxsld@tom.com', 'http://gf10.com.br/url/iq2f', '172.245.124.196', '2015-08-10 17:48:56', '2015-08-10 17:48:56', 'I was just looking at your Hello world! | Consult Lawyers website and see that your website has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are interested in topics like yours. By getting your site on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: https://spna.ca/1pvm - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the network I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular sites are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://www.urlator.co/w7uk', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(22, 1, 'Valerie', 'mndouvnrkzm@tom.com', 'http://ittsy.com/it/3x', '107.172.0.41', '2015-08-19 10:06:41', '2015-08-19 10:06:41', 'I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to get a lot of visitors. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for topics like yours. By getting your site on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can find out more about it here: http://tgi.link/dcf2 - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your site on the service I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular sites are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Find out more here: http://ittsy.com/it/3x', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)', '', 0, 0),
(23, 1, 'Valerie', 'qfgbjthlrod@tom.com', 'http://www.urlator.co/w7uk', '107.172.8.55', '2015-08-26 11:31:55', '2015-08-26 11:31:55', 'I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website network which already has more than 16 million users, and most of the users are looking for websites like yours. By getting your website on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://ittsy.com/it/3x - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular sites are using this service to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://www.urlator.co/w7uk', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.0.3705)', '', 0, 0),
(24, 1, 'Lindsey', 'bpgyqv@tom.com', 'http://www.arvut.org/1/dft', '172.245.120.6', '2015-09-01 18:34:45', '2015-09-01 18:34:45', 'I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website network which already has more than 16 million users, and the majority of the users are looking for topics like yours. By getting your website on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can find out more about it here: http://www.arvut.org/1/dft - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the network I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the network before paying anything. All the popular websites are using this service to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://digitalvikn.com.br/u/nk00', 0, '0', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(25, 1, 'Lindsey', 'vzigsng@tom.com', 'http://ittsy.com/it/3x', '172.245.120.6', '2015-09-09 21:50:47', '2015-09-09 21:50:47', 'I was just looking at your Hello world! | Consult Lawyers site and see that your website has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website network which already has more than 16 million users, and most of the users are interested in websites like yours. By getting your website on this network you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can find out more about it here: http://digitalvikn.com.br/u/nk00 - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your website on the network I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular sites are using this service to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful site works... Here''s to your success! Find out more here: http://www.arvut.org/1/dft', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '', 0, 0),
(26, 1, 'Lindsey', 'ffsspscbio@tom.com', 'http://ittsy.com/it/3x', '107.173.160.6', '2015-09-26 21:04:23', '2015-09-26 21:04:23', 'I was just looking at your Hello world! | Consult Lawyers site and see that your site has the potential to become very popular. I just want to tell you, In case you didn''t already know... There is a website network which already has more than 16 million users, and the majority of the users are looking for topics like yours. By getting your site on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://bbqr.me/4fj5 - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the network I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular sites are using this network to boost their readership and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://www.arvut.org/1/dft', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '', 0, 0),
(27, 1, 'Lindsey', 'wcablahyt@tom.com', 'http://ittsy.com/it/3x', '23.95.201.66', '2015-10-09 11:01:24', '2015-10-09 11:01:24', 'I was just looking at your Hello world! | Consult Lawyers website and see that your site has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and the majority of the users are interested in websites like yours. By getting your site on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://ittsy.com/it/3x - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the network I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular blogs are using this network to boost their traffic and ad revenue! Why aren’t you? And what is better than traffic? It’s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://ittsy.com/it/3x', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table`wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2333 ;

--
-- Dumping data for table 'wp_options'
--

INSERT INTO `wp_options` VALUES
(1, 'siteurl', 'http://consultlawyers.us/web', 'yes'),
(2, 'home', 'http://consultlawyers.us/web', 'yes'),
(3, 'blogname', 'Consult Lawyers', 'yes'),
(4, 'blogdescription', 'Get Help From Lawyers', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@consultlawyers.us', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'twentyfourteen', 'yes'),
(42, 'stylesheet', 'twentyfourteen', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '33056', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'posts', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '0', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";N;s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:4:{i:1444413333;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1444413393;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1444417440;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes'),
(107, '_transient_random_seed', 'f32bbe92d4b873a021d61b9cf0223fb5', 'yes'),
(128, 'recently_activated', 'a:0:{}', 'yes'),
(130, '_transient_is_multi_author', '0', 'yes'),
(131, '_transient_twentyfourteen_category_count', '1', 'yes'),
(132, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1426701480;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(133, 'current_theme', 'Twenty Fourteen', 'yes'),
(134, 'theme_mods_twentyfourteen', 'a:1:{i:0;b:0;}', 'yes'),
(135, 'theme_switched', '', 'yes'),
(137, '_transient_featured_content_ids', 'a:0:{}', 'yes'),
(138, 'category_children', 'a:0:{}', 'yes'),
(395, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:23:"admin@consultlawyers.us";s:7:"version";s:5:"4.3.1";s:9:"timestamp";i:1442342485;}', 'yes'),
(438, 'db_upgraded', '', 'yes'),
(1816, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1444381870;s:7:"checked";a:3:{s:13:"twentyfifteen";s:3:"1.3";s:14:"twentyfourteen";s:3:"1.5";s:14:"twentythirteen";s:3:"1.6";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'),
(1818, 'finished_splitting_shared_terms', '1', 'yes'),
(2065, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1444381866;s:15:"version_checked";s:5:"4.3.1";s:12:"translations";a:0:{}}', 'yes'),
(2328, '_site_transient_timeout_theme_roots', '1444383667', 'yes'),
(2329, '_site_transient_theme_roots', 'a:3:{s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes'),
(2332, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1444381870;s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.4";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.4.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:1:{s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}}}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table`wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table 'wp_postmeta'
--

INSERT INTO `wp_postmeta` VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 1, '_edit_lock', '1426706860:1');

-- --------------------------------------------------------

--
-- Table structure for table`wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table 'wp_posts'
--

INSERT INTO `wp_posts` VALUES
(1, 1, '2015-03-18 17:55:27', '2015-03-18 17:55:27', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-03-18 17:55:27', '2015-03-18 17:55:27', '', 0, 'http://consultlawyers.us/web/?p=1', 0, 'post', '', 1),
(2, 1, '2015-03-18 17:55:27', '2015-03-18 17:55:27', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://consultlawyers.us/web/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2015-03-18 17:55:27', '2015-03-18 17:55:27', '', 0, 'http://consultlawyers.us/web/?page_id=2', 0, 'page', '', 0),
(3, 1, '2015-03-18 17:56:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 17:56:34', '0000-00-00 00:00:00', '', 0, 'http://consultlawyers.us/web/?p=3', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table`wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'wp_terms'
--

INSERT INTO `wp_terms` VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Table structure for table`wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'wp_term_relationships'
--

INSERT INTO `wp_term_relationships` VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table`wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'wp_term_taxonomy'
--

INSERT INTO `wp_term_taxonomy` VALUES
(1, 1, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table`wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table 'wp_usermeta'
--

INSERT INTO `wp_usermeta` VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"402051dfb818de3e27266b3158c42035917d92c55e8d5a2327c33d38b2241310";a:4:{s:10:"expiration";i:1426874193;s:2:"ip";s:15:"206.208.102.250";s:2:"ua";s:135:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36 FirePHP/4Chrome";s:5:"login";i:1426701393;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '3');

-- --------------------------------------------------------

--
-- Table structure for table`wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'wp_users'
--

INSERT INTO `wp_users` VALUES
(1, 'admin', '$P$Bi8OK5eougNsq1Ny20uqtc0AW4JPhx1', 'admin', 'admin@consultlawyers.us', '', '2015-03-18 17:55:27', '', 0, 'admin');

-- --------------------------------------------------------

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
